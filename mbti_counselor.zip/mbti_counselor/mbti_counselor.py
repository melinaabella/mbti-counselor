from mbti_keys import Category
from table import DeStress 
from user import UserMBTI

if __name__ == "__main__":
    user_entry = UserMBTI()
    user_entry.personality_type()
    user_entry.e_types()
    user_entry.i_types()
